barang =("B001", "laptop Gaming", 15000000)

print(barang[2])

#barang[2]=14000000
#print(barang[2])
#tuple itu tidak bisa diubah

(kode, nama, harga)=barang

print(kode)
print(nama)
print(harga)